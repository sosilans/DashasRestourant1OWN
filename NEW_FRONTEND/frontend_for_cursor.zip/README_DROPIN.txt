Drop-in Frontend (Vite React)

How to use:
1) Extract all files from this archive into the target folder (root or subfolder).
2) Ensure .htaccess is present for SPA routing (Apache).
3) No server build needed. Assets use relative paths. If using subfolder, you may set RewriteBase in .htaccess.
