
  # Design HERO Section (Copy)

  This is a code bundle for Design HERO Section (Copy). The original project is available at https://www.figma.com/design/03QDZ47VLyaQ11IjK1je2W/Design-HERO-Section--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  